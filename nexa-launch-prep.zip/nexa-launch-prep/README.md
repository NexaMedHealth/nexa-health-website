# Nexa Health deployment preparation

Start with `README-LAUNCH.md`. This is a staging bundle, not yet a production-ready release. The original ZIPs should be retained as backups.
