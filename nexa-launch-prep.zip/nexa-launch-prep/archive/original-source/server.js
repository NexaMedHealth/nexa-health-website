/* ==========================================================================
   NEXA HEALTH - NODE.JS REST API BACKEND SERVER
   Zero external dependencies. Operates over HTTP & stores data persistently
   in db.json.
   ========================================================================== */

const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const PORT = process.env.PORT || 8085;
const DB_FILE = path.join(__dirname, 'db.json');

// MIME types dictionary for static file serving
const MIME_TYPES = {
  '.html': 'text/html',
  '.css': 'text/css',
  '.js': 'application/javascript',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

// Database Helper Functions
function readDb() {
  try {
    if (!fs.existsSync(DB_FILE)) {
      return { users: [], cycle: {}, symptoms: [], discussions: [], ambassadors: [], pledges: [] };
    }
    const data = fs.readFileSync(DB_FILE, 'utf8');
    return JSON.parse(data);
  } catch (err) {
    console.error('Error reading db.json:', err);
    return { users: [], cycle: {}, symptoms: [], discussions: [], ambassadors: [], pledges: [] };
  }
}

function writeDb(dbData) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(dbData, null, 2), 'utf8');
    return true;
  } catch (err) {
    console.error('Error writing to db.json:', err);
    return false;
  }
}

// Request Body Parser Helper
function parseRequestBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => body += chunk.toString());
    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (err) {
        resolve({});
      }
    });
    req.on('error', err => reject(err));
  });
}

// Send JSON Response Helper
function sendJson(res, statusCode, payload) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization'
  });
  res.end(JSON.stringify(payload));
}

// Main HTTP Server Request Router
const server = http.createServer(async (req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;
  const method = req.method;

  // Handle CORS Preflight
  if (method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization'
    });
    return res.end();
  }

  // API ROUTING LOGIC
  if (pathname.startsWith('/api/')) {

    // 1. Health Check
    if (pathname === '/api/health' && method === 'GET') {
      return sendJson(res, 200, { status: 'OK', message: 'Nexa Health REST API is running.' });
    }

    // 2. Authentication API
    if (pathname === '/api/auth/login' && method === 'POST') {
      const body = await parseRequestBody(req);
      const { email, password } = body;
      return sendJson(res, 200, {
        success: true,
        message: 'Credentials valid. 2FA OTP code dispatched.',
        demoOtp: '123456'
      });
    }

    if (pathname === '/api/auth/verify-2fa' && method === 'POST') {
      const body = await parseRequestBody(req);
      const { otp, email } = body;
      if (otp === '123456' || (otp && otp.length === 6)) {
        const db = readDb();
        let user = db.users.find(u => u.email === email);
        if (!user) {
          user = { id: Date.now(), name: email.split('@')[0], email };
          db.users.push(user);
          writeDb(db);
        }
        return sendJson(res, 200, { success: true, user });
      } else {
        return sendJson(res, 400, { success: false, message: 'Invalid OTP passcode.' });
      }
    }

    if (pathname === '/api/auth/register' && method === 'POST') {
      const body = await parseRequestBody(req);
      const db = readDb();
      const newUser = {
        id: Date.now(),
        name: body.name,
        email: body.email,
        dob: body.dob,
        country: body.country,
        city: body.city,
        language: body.language,
        interests: body.interests || []
      };
      db.users.push(newUser);
      writeDb(db);
      return sendJson(res, 201, { success: true, user: newUser });
    }

    // 3. Period & Cycle API
    if (pathname === '/api/cycle' && method === 'GET') {
      const db = readDb();
      return sendJson(res, 200, db.cycle || {});
    }

    if (pathname === '/api/cycle' && method === 'POST') {
      const body = await parseRequestBody(req);
      const db = readDb();
      db.cycle = {
        lastPeriodDate: body.lastPeriodDate,
        cycleLength: parseInt(body.cycleLength) || 28,
        periodDuration: parseInt(body.periodDuration) || 5
      };
      writeDb(db);
      return sendJson(res, 200, { success: true, cycle: db.cycle });
    }

    // 4. Symptoms API
    if (pathname === '/api/symptoms' && method === 'GET') {
      const db = readDb();
      return sendJson(res, 200, db.symptoms || []);
    }

    if (pathname === '/api/symptoms' && method === 'POST') {
      const body = await parseRequestBody(req);
      const db = readDb();
      const entry = {
        id: Date.now(),
        date: body.date,
        category: body.category,
        name: body.name,
        severity: parseInt(body.severity) || 3,
        notes: body.notes || ''
      };
      db.symptoms.unshift(entry);
      writeDb(db);
      return sendJson(res, 201, { success: true, entry });
    }

    // 5. Community Discussions API
    if (pathname === '/api/discussions' && method === 'GET') {
      const db = readDb();
      return sendJson(res, 200, db.discussions || []);
    }

    if (pathname === '/api/discussions' && method === 'POST') {
      const body = await parseRequestBody(req);
      const db = readDb();
      const topic = {
        id: Date.now(),
        author: body.author || 'Anonymous Member',
        tag: body.tag || 'Menstrual Health',
        title: body.title,
        content: body.content,
        upvotes: 1,
        comments: 0,
        liked: true,
        timestamp: 'Just now'
      };
      db.discussions.unshift(topic);
      writeDb(db);
      return sendJson(res, 201, { success: true, topic });
    }

    if (pathname.startsWith('/api/discussions/') && pathname.endsWith('/upvote') && method === 'POST') {
      const parts = pathname.split('/');
      const discId = parseInt(parts[3]);
      const db = readDb();
      const disc = db.discussions.find(d => d.id === discId);
      if (disc) {
        if (disc.liked) {
          disc.upvotes = Math.max(0, disc.upvotes - 1);
          disc.liked = false;
        } else {
          disc.upvotes += 1;
          disc.liked = true;
        }
        writeDb(db);
        return sendJson(res, 200, { success: true, discussion: disc });
      }
      return sendJson(res, 404, { success: false, message: 'Discussion not found.' });
    }

    // 6. Ambassador Applications API
    if (pathname === '/api/ambassadors' && method === 'GET') {
      const db = readDb();
      return sendJson(res, 200, db.ambassadors || []);
    }

    if (pathname === '/api/ambassadors' && method === 'POST') {
      const body = await parseRequestBody(req);
      const db = readDb();
      const appObj = {
        id: Date.now(),
        name: body.name,
        email: body.email,
        region: body.region,
        hours: body.hours,
        reason: body.reason,
        status: 'Under Review',
        date: new Date().toISOString().split('T')[0]
      };
      db.ambassadors.unshift(appObj);
      writeDb(db);
      return sendJson(res, 201, { success: true, application: appObj });
    }

    // 7. Flow Forward Pledges API
    if (pathname === '/api/pledges' && method === 'GET') {
      const db = readDb();
      return sendJson(res, 200, db.pledges || []);
    }

    if (pathname === '/api/pledges' && method === 'POST') {
      const body = await parseRequestBody(req);
      const db = readDb();
      const pledgeObj = {
        id: Date.now(),
        name: body.name,
        email: body.email,
        amount: parseInt(body.amount) || 10,
        role: body.role,
        impact: `${(parseInt(body.amount) || 10) / 10} Kit(s) Supplied`,
        date: new Date().toISOString().split('T')[0]
      };
      db.pledges.unshift(pledgeObj);
      writeDb(db);
      return sendJson(res, 201, { success: true, pledge: pledgeObj });
    }

    // Fallback API 404
    return sendJson(res, 404, { error: 'API endpoint not found.' });
  }

  // STATIC FILE SERVING
  let filePath = path.join(__dirname, pathname === '/' ? 'index.html' : pathname);
  const extname = path.extname(filePath);
  let contentType = MIME_TYPES[extname] || 'application/octet-stream';

  fs.readFile(filePath, (err, content) => {
    if (err) {
      if (err.code === 'ENOENT') {
        res.writeHead(404, { 'Content-Type': 'text/html' });
        res.end('<h1>404 Not Found</h1>');
      } else {
        res.writeHead(500);
        res.end(`Server Error: ${err.code}`);
      }
    } else {
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(content, 'utf-8');
    }
  });
});

server.listen(PORT, () => {
  console.log(`====================================================`);
  console.log(`🚀 NEXA HEALTH REST API SERVER IS LIVE`);
  console.log(`URL: http://localhost:${PORT}`);
  console.log(`API Health: http://localhost:${PORT}/api/health`);
  console.log(`Database File: ${DB_FILE}`);
  console.log(`====================================================`);
});
