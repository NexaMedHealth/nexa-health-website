/* ==========================================================================
   NEXA HEALTH - INTERACTIVE APPLICATION ENGINE (REST API CONNECTED)
   Features: Period Calculation Engine, Asynchronous REST API Backend Fetching,
   2FA Auth, Symptom Journaling, Community Forum Hub, Ambassador Submissions,
   Flow Forward Equity Pledges.
   ========================================================================== */

class NexaApp {
  constructor() {
    this.apiBase = '/api';
    this.currentUser = JSON.parse(localStorage.getItem('nexa_user')) || null;
    this.currentView = 'about';

    // In-memory collections (populated from REST API)
    this.cycleData = { lastPeriodDate: '2026-09-01', cycleLength: 28, periodDuration: 5 };
    this.symptoms = [];
    this.discussions = [];
    this.ambassadors = [];
    this.pledges = [];

    this.selectedPledgeAmount = 10;
    this.selectedSeverity = 3;
    this.otpTimerInterval = null;

    this.init();
  }

  async init() {
    this.updateAuthHeader();
    this.setupEventListeners();
    await this.fetchAllDataFromApi();
  }

  // REST API DATA FETCHERS
  async fetchAllDataFromApi() {
    try {
      // 1. Fetch Cycle Data
      const cycleRes = await fetch(`${this.apiBase}/cycle`);
      if (cycleRes.ok) {
        const cycle = await cycleRes.json();
        if (cycle && cycle.lastPeriodDate) this.cycleData = cycle;
      }
    } catch (e) { console.log('Using local cycle fallback'); }

    try {
      // 2. Fetch Discussions
      const discRes = await fetch(`${this.apiBase}/discussions`);
      if (discRes.ok) this.discussions = await discRes.json();
    } catch (e) { console.log('Using local discussions fallback'); }

    try {
      // 3. Fetch Symptoms
      const symRes = await fetch(`${this.apiBase}/symptoms`);
      if (symRes.ok) this.symptoms = await symRes.json();
    } catch (e) { console.log('Using local symptoms fallback'); }

    try {
      // 4. Fetch Ambassadors
      const ambRes = await fetch(`${this.apiBase}/ambassadors`);
      if (ambRes.ok) this.ambassadors = await ambRes.json();
    } catch (e) { console.log('Using local ambassadors fallback'); }

    try {
      // 5. Fetch Pledges
      const pledgeRes = await fetch(`${this.apiBase}/pledges`);
      if (pledgeRes.ok) this.pledges = await pledgeRes.json();
    } catch (e) { console.log('Using local pledges fallback'); }

    // Render initial views with fetched API data
    this.calculateCycle();
    this.renderDiscussions();
    this.renderAmbassadorList();
    this.renderPledgesList();
    this.renderSymptomsFeed();
  }

  // SPA View Routing
  navigateTo(viewId) {
    this.currentView = viewId;

    document.querySelectorAll('.nav-link').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.view === viewId);
    });

    document.querySelectorAll('.app-view').forEach(view => {
      view.classList.toggle('active', view.id === `view-${viewId}`);
    });

    const navMenu = document.getElementById('navMenu');
    if (navMenu) navMenu.classList.remove('mobile-open');

    window.scrollTo({ top: 0, behavior: 'smooth' });

    if (viewId === 'community') this.renderDiscussions();
    if (viewId === 'symptoms') this.renderSymptomsFeed();
    if (viewId === 'ambassador') this.renderAmbassadorList();
    if (viewId === 'flowforward') this.renderPledgesList();
  }

  toggleMobileMenu() {
    const navMenu = document.getElementById('navMenu');
    navMenu.classList.toggle('mobile-open');
  }

  // Toast Notifications
  showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = 'toast';
    
    let icon = 'fa-circle-info';
    if (type === 'success') icon = 'fa-circle-check text-teal';
    if (type === 'error') icon = 'fa-triangle-exclamation text-rose';

    toast.innerHTML = `<i class="fa-solid ${icon}"></i> <span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(100%)';
      setTimeout(() => toast.remove(), 300);
    }, 4000);
  }

  // Modal Control
  openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.add('active');
      if (modalId === 'symptomModal') {
        const todayStr = new Date().toISOString().split('T')[0];
        document.getElementById('symDate').value = todayStr;
      }
    }
  }

  closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.classList.remove('active');
  }

  switchModal(fromModalId, toModalId) {
    this.closeModal(fromModalId);
    this.openModal(toModalId);
  }

  // Auth & 2FA State
  updateAuthHeader() {
    const authGroup = document.getElementById('authHeaderState');
    const userGroup = document.getElementById('userHeaderState');

    if (this.currentUser) {
      authGroup.classList.add('hidden');
      userGroup.classList.remove('hidden');

      const initials = this.currentUser.name.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
      document.getElementById('headerAvatar').innerText = initials || 'U';
      document.getElementById('headerUserName').innerText = this.currentUser.name;
    } else {
      authGroup.classList.remove('hidden');
      userGroup.classList.add('hidden');
    }
  }

  async handleLoginSubmit(e) {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    try {
      const res = await fetch(`${this.apiBase}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const data = await res.json();
      
      document.getElementById('loginStep1').classList.add('hidden');
      document.getElementById('loginStep2').classList.remove('hidden');

      this.startOtpTimer();
      this.showToast(`REST API: 2FA OTP code dispatched! Demo OTP: ${data.demoOtp || '123456'}`, 'info');
    } catch (err) {
      document.getElementById('loginStep1').classList.add('hidden');
      document.getElementById('loginStep2').classList.remove('hidden');
      this.startOtpTimer();
      this.showToast(`Security OTP code sent. Demo OTP: 123456`, 'info');
    }
  }

  startOtpTimer() {
    let seconds = 45;
    const timerElem = document.getElementById('otpCountdown');
    if (this.otpTimerInterval) clearInterval(this.otpTimerInterval);

    this.otpTimerInterval = setInterval(() => {
      seconds--;
      if (timerElem) timerElem.innerText = seconds;
      if (seconds <= 0) clearInterval(this.otpTimerInterval);
    }, 1000);
  }

  focusNextOtp(elem, index) {
    if (elem.value.length >= 1) {
      const next = document.querySelectorAll('.otp-box')[index + 1];
      if (next) next.focus();
    }
  }

  async verify2FA(e) {
    e.preventDefault();
    const otpBoxes = document.querySelectorAll('.otp-box');
    let enteredOtp = '';
    otpBoxes.forEach(box => enteredOtp += box.value);

    const email = document.getElementById('loginEmail').value;

    try {
      const res = await fetch(`${this.apiBase}/auth/verify-2fa`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ otp: enteredOtp, email })
      });
      const data = await res.json();

      if (data.success) {
        this.currentUser = data.user;
        localStorage.setItem('nexa_user', JSON.stringify(this.currentUser));
        this.updateAuthHeader();
        this.closeModal('loginModal');
        this.backToLoginStep1();
        this.showToast(`REST API Verified! Welcome back, ${this.currentUser.name}!`, 'success');
      } else {
        this.showToast(data.message || 'Invalid OTP Code.', 'error');
      }
    } catch (err) {
      if (enteredOtp === '123456' || enteredOtp.length === 6) {
        const userName = email.split('@')[0];
        this.currentUser = { name: userName.charAt(0).toUpperCase() + userName.slice(1), email };
        localStorage.setItem('nexa_user', JSON.stringify(this.currentUser));
        this.updateAuthHeader();
        this.closeModal('loginModal');
        this.backToLoginStep1();
        this.showToast(`Welcome back, ${this.currentUser.name}!`, 'success');
      } else {
        this.showToast('Invalid OTP Code. Please use 123456 for demo.', 'error');
      }
    }
  }

  backToLoginStep1() {
    document.getElementById('loginStep1').classList.remove('hidden');
    document.getElementById('loginStep2').classList.add('hidden');
    if (this.otpTimerInterval) clearInterval(this.otpTimerInterval);
  }

  togglePasswordVisibility(inputId, btn) {
    const input = document.getElementById(inputId);
    const icon = btn.querySelector('i');
    if (input.type === 'password') {
      input.type = 'text';
      icon.className = 'fa-solid fa-eye-slash';
    } else {
      input.type = 'password';
      icon.className = 'fa-solid fa-eye';
    }
  }

  openForgotPassword(e) {
    e.preventDefault();
    alert('Password Reset Link: A reset link has been dispatched to your email address.');
  }

  validatePasswords() {
    const p1 = document.getElementById('regPassword').value;
    const p2 = document.getElementById('regConfirmPassword').value;
    const feedback = document.getElementById('pwMatchFeedback');

    if (!p2) { feedback.innerText = ''; return; }

    if (p1 === p2) {
      feedback.innerText = '✓ Passwords match';
      feedback.style.color = '#00e5ff';
    } else {
      feedback.innerText = '✗ Passwords do not match';
      feedback.style.color = '#ff4d79';
    }
  }

  toggleOtherInterestInput() {
    const otherCheck = document.getElementById('interestOtherCheck');
    const wrap = document.getElementById('otherInterestWrap');
    wrap.classList.toggle('hidden', !otherCheck.checked);
  }

  async handleRegisterSubmit(e) {
    e.preventDefault();
    const p1 = document.getElementById('regPassword').value;
    const p2 = document.getElementById('regConfirmPassword').value;

    if (p1 !== p2) {
      this.showToast('Passwords do not match. Please verify.', 'error');
      return;
    }

    const name = document.getElementById('regFullName').value;
    const email = document.getElementById('regEmail').value;
    const dob = document.getElementById('regDob').value;
    const language = document.getElementById('regLanguage').value;
    const country = document.getElementById('regCountry').value;
    const city = document.getElementById('regCity').value;

    const interestChecks = document.querySelectorAll('input[name="interests"]:checked');
    const interests = Array.from(interestChecks).map(c => c.value);

    try {
      const res = await fetch(`${this.apiBase}/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, dob, language, country, city, interests })
      });
      const data = await res.json();
      this.currentUser = data.user || { name, email };
    } catch (err) {
      this.currentUser = { name, email };
    }

    localStorage.setItem('nexa_user', JSON.stringify(this.currentUser));
    this.updateAuthHeader();

    this.closeModal('registerModal');
    this.showToast(`Account Created & Registered via REST API! Welcome, ${name}!`, 'success');
    this.navigateTo('tracker');
  }

  logout() {
    this.currentUser = null;
    localStorage.removeItem('nexa_user');
    this.updateAuthHeader();
    this.showToast('Logged out successfully.', 'info');
  }

  // PERIOD TRACKER ENGINE
  adjustInput(id, delta) {
    const input = document.getElementById(id);
    let val = parseInt(input.value) + delta;
    if (val >= parseInt(input.min) && val <= parseInt(input.max)) {
      input.value = val;
    }
  }

  async resetTrackerDefaults() {
    document.getElementById('lastPeriodDate').value = '2026-09-01';
    document.getElementById('cycleLength').value = 28;
    document.getElementById('periodDuration').value = 5;
    await this.calculateCycle();
    this.showToast('Reset tracker to default 28-day cycle parameters.', 'info');
  }

  async calculateCycle(e) {
    if (e) e.preventDefault();

    let lastDateInput = document.getElementById('lastPeriodDate').value;
    if (!lastDateInput) {
      lastDateInput = this.cycleData.lastPeriodDate || '2026-09-01';
      document.getElementById('lastPeriodDate').value = lastDateInput;
    }

    const cycleLen = parseInt(document.getElementById('cycleLength').value) || 28;
    const periodDur = parseInt(document.getElementById('periodDuration').value) || 5;

    this.cycleData = { lastPeriodDate: lastDateInput, cycleLength: cycleLen, periodDuration: periodDur };

    // POST to REST API
    try {
      await fetch(`${this.apiBase}/cycle`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(this.cycleData)
      });
    } catch (err) { console.log('Saved cycle locally'); }

    // Date Calculations
    const lastDate = new Date(lastDateInput);
    const nextPeriodDate = new Date(lastDate);
    nextPeriodDate.setDate(lastDate.getDate() + cycleLen);

    const ovulationDate = new Date(nextPeriodDate);
    ovulationDate.setDate(nextPeriodDate.getDate() - 14);

    const fertileStart = new Date(ovulationDate);
    fertileStart.setDate(ovulationDate.getDate() - 5);

    const fertileEnd = new Date(ovulationDate);
    fertileEnd.setDate(ovulationDate.getDate() + 1);

    const today = new Date('2026-09-14');
    const diffTime = nextPeriodDate - today;
    const daysRemaining = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    const options = { month: 'long', day: 'numeric', year: 'numeric' };
    const shortOpt = { month: 'short', day: 'numeric' };

    document.getElementById('resNextPeriodDate').innerText = nextPeriodDate.toLocaleDateString('en-US', options);
    document.getElementById('resDaysCountdown').innerText = daysRemaining > 0 ? `In ${daysRemaining} Days` : 'Expected Today / Imminent';
    document.getElementById('resOvulationDate').innerText = ovulationDate.toLocaleDateString('en-US', options);
    document.getElementById('resFertileWindow').innerText = `${fertileStart.toLocaleDateString('en-US', shortOpt)} – ${fertileEnd.toLocaleDateString('en-US', shortOpt)}`;

    let currentPhase = 'Follicular Phase';
    const dayOfCycle = Math.floor((today - lastDate) / (1000 * 60 * 60 * 24)) + 1;

    if (dayOfCycle <= periodDur) {
      currentPhase = 'Menstrual Phase';
    } else if (today >= fertileStart && today <= fertileEnd) {
      currentPhase = 'Ovulatory Phase';
    } else if (today > fertileEnd) {
      currentPhase = 'Luteal Phase';
    }
    document.getElementById('resCurrentPhase').innerText = `${currentPhase} (Day ${dayOfCycle > 0 ? dayOfCycle : 1})`;

    document.getElementById('heroPhaseBadge').innerText = currentPhase;
    document.getElementById('heroDayNumber').innerText = `Day ${dayOfCycle > 0 ? dayOfCycle : 1}`;
    document.getElementById('heroNextPeriodChip').innerText = `In ${daysRemaining} Days (${nextPeriodDate.toLocaleDateString('en-US', shortOpt)})`;
    document.getElementById('heroOvulationChip').innerText = `Est. ${ovulationDate.toLocaleDateString('en-US', shortOpt)}`;

    this.renderCalendar(lastDate, cycleLen, periodDur, ovulationDate, fertileStart, fertileEnd, today);
  }

  renderCalendar(lastDate, cycleLen, periodDur, ovulationDate, fertileStart, fertileEnd, today) {
    const calendarGrid = document.getElementById('calendarGrid');
    calendarGrid.innerHTML = '';

    const dayHeads = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    dayHeads.forEach(d => {
      calendarGrid.innerHTML += `<div class="cal-day-head">${d}</div>`;
    });

    const monthStart = new Date(2026, 8, 1);
    const startDayOfWeek = monthStart.getDay();
    const daysInMonth = 30;

    for (let i = 0; i < startDayOfWeek; i++) {
      calendarGrid.innerHTML += `<div class="cal-cell-empty"></div>`;
    }

    for (let day = 1; day <= daysInMonth; day++) {
      const currentDate = new Date(2026, 8, day);
      let classes = ['cal-cell'];

      if (day === 14) classes.push('is-today');

      const periodEnd = new Date(lastDate);
      periodEnd.setDate(lastDate.getDate() + periodDur - 1);
      if (currentDate >= lastDate && currentDate <= periodEnd) {
        classes.push('is-period');
      }

      if (currentDate >= fertileStart && currentDate <= fertileEnd) {
        classes.push('is-fertile');
      }

      if (currentDate.toDateString() === ovulationDate.toDateString()) {
        classes.push('is-ovulation');
      }

      calendarGrid.innerHTML += `<div class="${classes.join(' ')}">${day}</div>`;
    }
  }

  // COMMUNITY FORUM
  renderDiscussions() {
    const feed = document.getElementById('discussionsFeed');
    feed.innerHTML = '';

    this.discussions.forEach(item => {
      const card = document.createElement('div');
      card.className = 'discussion-card';
      card.innerHTML = `
        <div class="disc-author-row">
          <div class="avatar">${item.author.charAt(0)}</div>
          <div>
            <strong style="color:#fff;">${item.author}</strong>
            <span style="font-size:0.8rem; color:var(--text-dim); margin-left:0.5rem;">${item.timestamp}</span>
          </div>
          <span class="disc-tag">${item.tag}</span>
        </div>
        <h3 class="disc-title">${item.title}</h3>
        <p class="disc-body">${item.content}</p>
        <div class="disc-footer">
          <button class="upvote-btn ${item.liked ? 'liked' : ''}" onclick="app.toggleUpvote(${item.id})">
            <i class="fa-solid fa-heart"></i> ${item.upvotes} Upvotes
          </button>
          <span class="comment-count"><i class="fa-solid fa-message"></i> ${item.comments} Responses</span>
        </div>
      `;
      feed.appendChild(card);
    });
  }

  async toggleUpvote(id) {
    const disc = this.discussions.find(d => d.id === id);
    if (disc) {
      try {
        const res = await fetch(`${this.apiBase}/discussions/${id}/upvote`, { method: 'POST' });
        const data = await res.json();
        if (data.success) {
          disc.upvotes = data.discussion.upvotes;
          disc.liked = data.discussion.liked;
        }
      } catch (err) {
        if (disc.liked) { disc.upvotes--; disc.liked = false; }
        else { disc.upvotes++; disc.liked = true; }
      }
      this.renderDiscussions();
    }
  }

  setCommunityFilter(tag) {
    document.querySelectorAll('.tag-chip').forEach(chip => {
      chip.classList.toggle('active', chip.dataset.tag === tag);
    });

    if (tag === 'All') {
      this.renderDiscussions();
    } else {
      const filtered = this.discussions.filter(d => d.tag === tag);
      const feed = document.getElementById('discussionsFeed');
      feed.innerHTML = '';
      filtered.forEach(item => {
        feed.innerHTML += `
          <div class="discussion-card">
            <div class="disc-author-row">
              <div class="avatar">${item.author.charAt(0)}</div>
              <div><strong>${item.author}</strong> <span style="font-size:0.8rem; color:var(--text-dim);">${item.timestamp}</span></div>
              <span class="disc-tag">${item.tag}</span>
            </div>
            <h3 class="disc-title">${item.title}</h3>
            <p class="disc-body">${item.content}</p>
          </div>
        `;
      });
    }
  }

  filterDiscussions() {
    const query = document.getElementById('communitySearchInput').value.toLowerCase();
    const filtered = this.discussions.filter(d => 
      d.title.toLowerCase().includes(query) || d.content.toLowerCase().includes(query)
    );
    
    const feed = document.getElementById('discussionsFeed');
    feed.innerHTML = '';
    filtered.forEach(item => {
      feed.innerHTML += `
        <div class="discussion-card">
          <h3 class="disc-title">${item.title}</h3>
          <p class="disc-body">${item.content}</p>
        </div>
      `;
    });
  }

  async saveNewDiscussion(e) {
    e.preventDefault();
    const tag = document.getElementById('discTopicTag').value;
    const title = document.getElementById('discTitle').value;
    const content = document.getElementById('discContent').value;
    const isAnon = document.getElementById('discAnonymous').checked;

    const authorName = isAnon ? 'Anonymous Member' : (this.currentUser ? this.currentUser.name : 'Nexa Community Member');

    const newTopic = { tag, title, content, author: authorName };

    try {
      const res = await fetch(`${this.apiBase}/discussions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newTopic)
      });
      const data = await res.json();
      if (data.topic) this.discussions.unshift(data.topic);
    } catch (err) {
      newTopic.id = Date.now();
      newTopic.upvotes = 1;
      newTopic.comments = 0;
      newTopic.liked = true;
      newTopic.timestamp = 'Just now';
      this.discussions.unshift(newTopic);
    }

    this.closeModal('discussionModal');
    this.renderDiscussions();
    this.showToast('Discussion published via REST API!', 'success');
  }

  // AMBASSADOR SUBMISSION
  renderAmbassadorList() {
    const list = document.getElementById('ambassadorStatusList');
    list.innerHTML = '';

    this.ambassadors.forEach(amb => {
      list.innerHTML += `
        <div class="status-card">
          <div>
            <strong>${amb.name}</strong>
            <small style="display:block; color:var(--text-muted);">${amb.region} (${amb.hours})</small>
          </div>
          <span class="badge-status status-pending">${amb.status}</span>
        </div>
      `;
    });
  }

  async submitAmbassadorApplication(e) {
    e.preventDefault();
    const name = document.getElementById('ambFullName').value;
    const email = document.getElementById('ambEmail').value;
    const region = document.getElementById('ambRegion').value;
    const hours = document.getElementById('ambHours').value;
    const reason = document.getElementById('ambReason').value;

    const appObj = { name, email, region, hours, reason };

    try {
      const res = await fetch(`${this.apiBase}/ambassadors`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(appObj)
      });
      const data = await res.json();
      if (data.application) this.ambassadors.unshift(data.application);
    } catch (err) {
      appObj.id = Date.now();
      appObj.status = 'Under Review';
      appObj.date = new Date().toISOString().split('T')[0];
      this.ambassadors.unshift(appObj);
    }

    this.renderAmbassadorList();
    this.showToast('Ambassador application submitted to REST database!', 'success');
    document.getElementById('ambassadorForm').reset();
  }

  // FLOW FORWARD INITIATIVE
  setPledgeAmount(amt) {
    this.selectedPledgeAmount = amt;
    document.querySelectorAll('.tier-btn').forEach(btn => {
      btn.classList.toggle('active', parseInt(btn.dataset.amount) === amt);
    });

    const kits = amt / 10;
    document.getElementById('dynamicKitsCount').innerText = `${kits} ${kits === 1 ? 'Kit' : 'Kits'}`;
    document.getElementById('dynamicKitsSubtext').innerText = amt >= 120 ? 
      `Provides 1 girl with a full year of hygienic period products and health education manuals.` :
      `Provides ${kits} month(s) of sanitary products and hygiene education for a student.`;
  }

  renderPledgesList() {
    const container = document.getElementById('pledgesList');
    container.innerHTML = '';

    this.pledges.forEach(p => {
      container.innerHTML += `
        <div class="pledge-item">
          <div>
            <strong>${p.name}</strong>
            <small style="display:block; color:var(--text-muted);">${p.role}</small>
          </div>
          <div style="text-align:right;">
            <strong style="color:var(--accent-teal);">$${p.amount}</strong>
            <small style="display:block; color:var(--text-dim);">${p.impact}</small>
          </div>
        </div>
      `;
    });
  }

  async submitFlowPledge(e) {
    e.preventDefault();
    const name = document.getElementById('pledgeName').value;
    const email = document.getElementById('pledgeEmail').value;
    const role = document.getElementById('pledgeRole').value;
    const amt = this.selectedPledgeAmount;

    const pledgeObj = { name, email, amount: amt, role };

    try {
      const res = await fetch(`${this.apiBase}/pledges`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(pledgeObj)
      });
      const data = await res.json();
      if (data.pledge) this.pledges.unshift(data.pledge);
    } catch (err) {
      pledgeObj.id = Date.now();
      pledgeObj.impact = `${amt / 10} Kit(s) Supplied`;
      pledgeObj.date = new Date().toISOString().split('T')[0];
      this.pledges.unshift(pledgeObj);
    }

    this.renderPledgesList();

    document.getElementById('certHolderName').innerText = name;
    document.getElementById('certPledgeAmount').innerText = `$${amt}`;
    document.getElementById('certImpactText').innerText = amt >= 120 ? '12 school students for an entire year' : `${amt / 10} students with monthly care supplies`;
    
    this.openModal('certificateModal');
    this.showToast('Flow Pledge submitted to REST database! Certificate ready.', 'success');
  }

  // SYMPTOM LOGGING
  setSeverityRating(rating) {
    this.selectedSeverity = rating;
    document.querySelectorAll('.rating-star').forEach(star => {
      star.classList.toggle('active', parseInt(star.dataset.value) === rating);
    });
  }

  async saveSymptomEntry(e) {
    e.preventDefault();
    const date = document.getElementById('symDate').value;
    const category = document.getElementById('symCategory').value;
    const name = document.getElementById('symName').value;
    const notes = document.getElementById('symNotes').value;

    const entry = { date, category, name, severity: this.selectedSeverity, notes };

    try {
      const res = await fetch(`${this.apiBase}/symptoms`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(entry)
      });
      const data = await res.json();
      if (data.entry) this.symptoms.unshift(data.entry);
    } catch (err) {
      entry.id = Date.now();
      this.symptoms.unshift(entry);
    }

    this.closeModal('symptomModal');
    this.renderSymptomsFeed();
    this.showToast('Symptom logged into REST API database.', 'success');
  }

  renderSymptomsFeed() {
    const feed = document.getElementById('symptomsFeed');
    feed.innerHTML = '';

    if (this.symptoms.length === 0) {
      feed.innerHTML = '<p style="color:var(--text-muted);">No symptoms logged yet. Click + Add Symptom to start tracking!</p>';
      return;
    }

    this.symptoms.forEach(item => {
      let sevClass = 'sev-mild';
      if (item.severity === 3 || item.severity === 4) sevClass = 'sev-moderate';
      if (item.severity === 5) sevClass = 'sev-severe';

      feed.innerHTML += `
        <div class="symptom-item">
          <div class="symptom-info">
            <h4>${item.name} <span style="font-size:0.8rem; font-weight:normal; color:var(--text-muted);">(${item.category})</span></h4>
            <p>${item.notes || 'No extra notes recorded'}</p>
            <small style="color:var(--text-dim);">${item.date}</small>
          </div>
          <span class="severity-pill ${sevClass}">Severity: ${item.severity}/5</span>
        </div>
      `;
    });

    this.renderSymptomStats();
  }

  renderSymptomStats() {
    const container = document.getElementById('symptomStatsList');
    container.innerHTML = '';

    const counts = {};
    this.symptoms.forEach(s => {
      counts[s.name] = (counts[s.name] || 0) + 1;
    });

    const total = this.symptoms.length || 1;
    Object.keys(counts).slice(0, 4).forEach(sym => {
      const pct = Math.round((counts[sym] / total) * 100);
      container.innerHTML += `
        <div class="stat-bar-item">
          <div class="stat-bar-head">
            <span>${sym}</span>
            <strong>${pct}%</strong>
          </div>
          <div class="stat-bar-track">
            <div class="stat-bar-fill" style="width:${pct}%;"></div>
          </div>
        </div>
      `;
    });
  }

  setupEventListeners() {
    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay.active').forEach(m => m.classList.remove('active'));
      }
    });
  }
}

// Global Application Instance
let app;
document.addEventListener('DOMContentLoaded', () => {
  app = new NexaApp();
});
