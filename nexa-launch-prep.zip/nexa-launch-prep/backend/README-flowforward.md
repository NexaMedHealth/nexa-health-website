# Nexa Health: Flow Forward backend

Verifies Paystack payments, issues **one certificate per verified payment**, emails it automatically, and stores every recipient so you can see who got one.
No npm packages to install. Needs **Node 22.13+**.

## How certificates are protected
1. Donor pays at https://paystack.shop/pay/FlowForward.
2. Paystack calls `POST /webhooks/paystack`. The server checks Paystack's HMAC signature, then saves the payment (reference, email, amount in kobo). Only successful NGN payments are saved.
3. The donor opens the website and enters their **email** (and ideally the **Paystack reference** from the receipt). The server looks the payment up. No verified payment = no certificate.
4. The **tier is set from the amount Paystack confirmed**, not from what the browser says. Under ₦1,000 gets none.
5. One payment = one certificate. Claiming again just resends the same one.
6. The certificate is **emailed to the email on the payment**. Only a claim with the matching reference *and* email shows it on screen; an email-only claim just sends the email.
7. Names appear in "Recent Flow Forward Supporters" only if the donor ticked the consent box.

## Run it locally
```
cp .env.example .env      # fill in values; MAIL_PROVIDER=console writes emails to ./outbox
node server.js            # http://localhost:8085
node test/smoke.js        # 20 end-to-end checks
```

## Deploy (example: Render.com)
1. Put this folder in a GitHub repo. New **Web Service**, build command empty, start command `node server.js`.
2. Add a **persistent disk** (e.g. mounted at `/data`) and set `DB_PATH=/data/nexa.db`. Without a disk the database is wiped on every deploy.
3. Set the env vars from `.env.example` (`BASE_URL` = your live URL).
4. In Paystack: **Settings > API Keys & Webhooks**. Set the **Live Webhook URL** to `https://YOUR-SITE/webhooks/paystack`. Copy the **secret key** into `PAYSTACK_SECRET_KEY`.
5. Do a real ₦1,000 test payment, then claim it on the site.

## Email provider
Pick one in `.env`:
- `brevo` (free tier 300/day): create an API key, verify your sender email or domain.
- `resend` (free tier): needs a verified domain to email anyone.
Use a sender on your own domain for best inbox delivery.

## Admin: who got a certificate
Open `https://YOUR-SITE/admin`, enter `ADMIN_TOKEN`. You get totals, every recipient (name, email, tier, amount, reference, email status), a **CSV download**, and a **Resend** button. Paid-but-not-yet-claimed payments are counted too.

## Notes
- If your Paystack account has other payment pages, set `PAYSTACK_PAGE_MATCH=FlowForward` so only this page's payments count. Check a real webhook payload first (it is stored in the `payments.raw` column).
- The Paystack **reference** is on the donor's Paystack receipt email. Asking for it makes claims much harder to guess.
- Rate limits: 12 claims/hour per IP, 6/hour per email.
- Back up `nexa.db`. You are holding donor emails: tell donors how you use them.
