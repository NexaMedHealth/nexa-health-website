'use strict';
// End-to-end smoke test. Run: node test/smoke.js   (uses a temp DB and the console mail provider)
const os = require('os'), fs = require('fs'), path = require('path'), crypto = require('crypto'), assert = require('assert');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'nexa-'));
Object.assign(process.env, { DB_PATH: path.join(tmp, 't.db'), PAYSTACK_SECRET_KEY: 'sk_test_secret', ADMIN_TOKEN: 'adm-token-123', MAIL_PROVIDER: 'console', BASE_URL: 'http://localhost:9999' });
const outbox = path.join(__dirname, '..', 'outbox'); fs.rmSync(outbox, { recursive: true, force: true });
const server = require('../server');
const secret = process.env.PAYSTACK_SECRET_KEY;
let n = 0; const ok = (m) => console.log('  ✓', m, `(${++n})`);

const tx = (ref, email, naira, extra = {}) => ({ event: 'charge.success', data: { reference: ref, status: 'success', amount: naira * 100, currency: 'NGN', paid_at: new Date().toISOString(), customer: { email, first_name: 'Ada', last_name: 'Obi' }, ...extra } });
async function run() {
  await new Promise(r => server.listen(0, r)); const base = 'http://localhost:' + server.address().port;
  const post = (p, body, headers = {}) => fetch(base + p, { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: typeof body === 'string' ? body : JSON.stringify(body) });
  const hook = (evt, sig) => { const raw = JSON.stringify(evt); return post('/webhooks/paystack', raw, { 'x-paystack-signature': sig || crypto.createHmac('sha512', secret).update(raw).digest('hex') }); };
  const claim = async b => { const r = await post('/api/certificates/claim', b); return { s: r.status, j: await r.json() }; };

  assert.strictEqual((await hook(tx('R0', 'x@y.com', 3000), 'deadbeef')).status, 401); ok('webhook with bad signature rejected');
  assert.strictEqual((await hook(tx('R1', 'donor@example.com', 3000))).status, 200); ok('valid webhook accepted');
  assert.strictEqual((await hook({ event: 'charge.success', data: { ...tx('R2', 'fail@example.com', 3000).data, status: 'failed' } })).status, 200);
  assert.strictEqual((await hook({ event: 'charge.success', data: { ...tx('R3', 'usd@example.com', 3000).data, currency: 'USD' } })).status, 200);
  await hook(tx('R4', 'small@example.com', 500));
  await hook(tx('R5', 'big@example.com', 7500));

  let r = await claim({ name: 'Ada Obi', email: 'donor@example.com', reference: 'NOPE' }); assert.strictEqual(r.s, 404); ok('unknown reference rejected');
  r = await claim({ name: 'Thief', email: 'thief@example.com', reference: 'R1' }); assert.strictEqual(r.s, 404); ok('right reference, wrong email rejected');
  r = await claim({ email: 'fail@example.com', reference: 'R2' }); assert.strictEqual(r.s, 404); ok('failed payment gets no certificate');
  r = await claim({ email: 'usd@example.com', reference: 'R3' }); assert.strictEqual(r.s, 404); ok('non-NGN payment gets no certificate');
  r = await claim({ email: 'small@example.com', reference: 'R4' }); assert.strictEqual(r.s, 422); ok('payment under ₦1,000 gets no certificate');
  r = await claim({ email: 'nobody@example.com' }); assert.strictEqual(r.s, 404); ok('email with no payment rejected');

  r = await claim({ name: 'Ada Obi', email: 'Donor@Example.com', reference: 'R1', showPublic: false });
  assert.strictEqual(r.s, 200); assert.strictEqual(r.j.certificate.tier, 'Flow Guardian'); assert.strictEqual(r.j.certificate.amountNaira, 3000); assert.strictEqual(r.j.emailed, true);
  ok('verified payment gets certificate; tier decided by amount paid (Flow Guardian), email case-insensitive');
  const first = r.j.certificate;
  const mails = fs.readdirSync(outbox); assert.strictEqual(mails.length, 1);
  const mailHtml = fs.readFileSync(path.join(outbox, mails[0]), 'utf8'); assert(mailHtml.includes('/c/' + first.token) && mailHtml.includes('donor@example.com')); ok('email written with certificate link');
  r = await claim({ name: 'Different Name', email: 'donor@example.com', reference: 'R1' }); assert.strictEqual(r.j.alreadyIssued, true); assert.strictEqual(r.j.certificate.certNo, first.certNo); assert.strictEqual(r.j.certificate.name, 'Ada Obi'); ok('second claim of same payment reissues the same certificate, no duplicate');

  r = await claim({ name: 'Big Giver', email: 'big@example.com', showPublic: true }); assert.strictEqual(r.s, 200); assert.strictEqual(r.j.emailOnly, true); assert.strictEqual(r.j.certificate, undefined); ok('email-only claim emails the donor but reveals no certificate data');
  let sup = await (await fetch(base + '/api/supporters')).json(); assert.deepStrictEqual(sup.map(s => s.name), ['Big Giver']); ok('only people who agreed appear in public supporters');

  assert.strictEqual((await fetch(base + '/api/admin/certificates')).status, 401);
  assert.strictEqual((await fetch(base + '/api/admin/certificates', { headers: { Authorization: 'Bearer wrong' } })).status, 401); ok('admin API locked without token');
  const H = { Authorization: 'Bearer adm-token-123' };
  const list = await (await fetch(base + '/api/admin/certificates', { headers: H })).json(); assert.strictEqual(list.length, 2); assert(list.some(c => c.email === 'donor@example.com' && c.email_status === 'sent')); assert(list.some(c => c.email === 'big@example.com' && c.tier === 'Flow Village')); ok('admin sees recipients and email status');
  const csv = await (await fetch(base + '/api/admin/certificates.csv', { headers: H })).text(); assert(csv.includes('donor@example.com') && csv.includes('Flow Village')); ok('CSV export contains stored emails');
  const sum = await (await fetch(base + '/api/admin/summary', { headers: H })).json(); assert.strictEqual(sum.certificates, 2); assert.strictEqual(sum.unclaimed_payments, 1); ok('admin summary correct (' + JSON.stringify(sum) + ')');

  assert.strictEqual((await fetch(base + '/api/certificates/' + first.token)).status, 200);
  assert.strictEqual((await fetch(base + '/api/certificates/' + 'a'.repeat(32))).status, 404);
  assert.strictEqual((await fetch(base + '/c/' + first.token)).status, 200);
  assert.strictEqual((await fetch(base + '/')).status, 200);
  assert.strictEqual((await fetch(base + '/admin')).status, 200); ok('pages and certificate lookups work');
  const trav = await fetch(base + '/..%2fserver.js'); assert.strictEqual(trav.status, 404); ok('path traversal blocked');
  console.log('\nAll checks passed.'); server.close(); process.exit(0);
}
run().catch(e => { console.error('FAILED:', e); process.exit(1); });
