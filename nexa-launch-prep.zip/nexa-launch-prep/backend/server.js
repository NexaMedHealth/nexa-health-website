'use strict';
/* Nexa Health: Flow Forward backend (zero npm dependencies, needs Node 22.13+)
   - Receives Paystack webhooks and records verified payments
   - Issues ONE certificate per verified payment, emails it, stores the recipient
   - Serves the website, the hosted certificate page, and a token-protected admin area */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const cfg = require('./lib/config');
const { openDb } = require('./lib/db');
const { validSignature, paymentFromTransaction } = require('./lib/paystack');
const certs = require('./lib/certs');

const db = openDb(cfg.dbPath);
const PUBLIC = path.join(__dirname, 'public');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.json': 'application/json' };

// ---- helpers
const hits = new Map();
const limited = (key, max, windowMs) => {
  const now = Date.now(); const a = (hits.get(key) || []).filter(t => now - t < windowMs); a.push(now); hits.set(key, a); return a.length > max;
};
setInterval(() => { const now = Date.now(); for (const [k, v] of hits) if (!v.some(t => now - t < 3600e3)) hits.delete(k); }, 600e3).unref();
const clientIp = req => (cfg.trustProxy && String(req.headers['x-forwarded-for'] || '').split(',')[0].trim()) || req.socket.remoteAddress || 'unknown';
function send(res, status, body, headers = {}) {
  const isObj = typeof body === 'object' && !Buffer.isBuffer(body);
  res.writeHead(status, { 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer', ...(isObj ? { 'Content-Type': 'application/json' } : {}), ...headers });
  res.end(isObj ? JSON.stringify(body) : body);
}
function readBody(req, max = 1e6) {
  return new Promise((resolve, reject) => {
    const chunks = []; let n = 0;
    req.on('data', c => { n += c.length; if (n > max) { reject(new Error('too large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}
function adminOk(req) {
  if (!cfg.adminToken) return false;
  const m = String(req.headers.authorization || '').match(/^Bearer (.+)$/);
  if (!m) return false;
  const a = Buffer.from(m[1]), b = Buffer.from(cfg.adminToken);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
const csvCell = v => { let s = String(v == null ? '' : v); if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; return '"' + s.replace(/"/g, '""') + '"'; };
function serveStatic(res, file) {
  const full = path.join(PUBLIC, file);
  if (!full.startsWith(PUBLIC) || !fs.existsSync(full) || !fs.statSync(full).isFile()) return send(res, 404, 'Not found');
  send(res, 200, fs.readFileSync(full), { 'Content-Type': MIME[path.extname(full)] || 'application/octet-stream', 'Cache-Control': file.endsWith('.html') ? 'no-cache' : 'public, max-age=3600' });
}

// ---- server
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x'); const p = url.pathname; const m = req.method;
  try {
    // Paystack webhook: the ONLY way a payment becomes "real" besides a server-side verify call
    if (p === '/webhooks/paystack' && m === 'POST') {
      if (!cfg.paystackSecret) return send(res, 503, { error: 'not configured' });
      const raw = await readBody(req);
      if (!validSignature(raw, req.headers['x-paystack-signature'], cfg.paystackSecret)) return send(res, 401, { error: 'bad signature' });
      let evt; try { evt = JSON.parse(raw.toString('utf8')); } catch (e) { return send(res, 400, { error: 'bad json' }); }
      if (evt.event === 'charge.success') {
        const rec = paymentFromTransaction(evt.data, cfg.paystackPageMatch);
        if (rec) { certs.savePayment(db, rec); console.log('[payment]', rec.reference, rec.email, rec.amount_kobo / 100, 'NGN'); }
        else console.log('[payment] ignored (not NGN success / page filter):', evt.data && evt.data.reference);
      }
      return send(res, 200, { received: true });
    }

    if (p === '/api/certificates/claim' && m === 'POST') {
      const ip = clientIp(req);
      if (limited('claim-ip:' + ip, 12, 3600e3)) return send(res, 429, { error: 'Too many attempts. Please try again later.' });
      let body; try { body = JSON.parse((await readBody(req, 20e3)).toString('utf8')); } catch (e) { return send(res, 400, { error: 'Invalid request.' }); }
      const emailKey = String(body.email || '').trim().toLowerCase();
      if (limited('claim-email:' + emailKey, 6, 3600e3)) return send(res, 429, { error: 'Too many attempts for this email. Please try again later.' });
      const r = await certs.claim(db, { name: body.name, email: body.email, reference: body.reference, showPublic: body.showPublic === true });
      return send(res, r.status, r.error ? { error: r.error } : r.body);
    }

    let mm;
    if ((mm = p.match(/^\/api\/certificates\/([A-Za-z0-9_-]{20,64})$/)) && m === 'GET') {
      const c = db.prepare('SELECT * FROM certificates WHERE token=?').get(mm[1]);
      return c ? send(res, 200, certs.publicView(c)) : send(res, 404, { error: 'Certificate not found' });
    }
    if (p === '/api/supporters' && m === 'GET') return send(res, 200, certs.supporters(db));
    if (p === '/api/health') return send(res, 200, { status: 'OK' });

    // ---- admin
    if (p.startsWith('/api/admin/')) {
      if (!adminOk(req)) return send(res, 401, { error: 'Unauthorized' });
      if (p === '/api/admin/summary') {
        return send(res, 200, db.prepare(`SELECT (SELECT COUNT(*) FROM payments) payments,
          (SELECT COUNT(*) FROM certificates) certificates,
          (SELECT COALESCE(SUM(amount_kobo),0)/100 FROM payments) total_naira,
          (SELECT COUNT(*) FROM certificates WHERE email_status!='sent') emails_not_sent,
          (SELECT COUNT(*) FROM payments p WHERE NOT EXISTS (SELECT 1 FROM certificates c WHERE c.reference=p.reference)) unclaimed_payments`).get());
      }
      if (p === '/api/admin/certificates') return send(res, 200, db.prepare('SELECT id,cert_no,name,email,tier,amount_kobo/100 AS amount_naira,reference,public_display,issued_at,email_status,email_sent_at,email_error FROM certificates ORDER BY id DESC').all());
      if (p === '/api/admin/payments') return send(res, 200, db.prepare(`SELECT p.reference,p.email,p.paystack_name,p.amount_kobo/100 AS amount_naira,p.paid_at,
        CASE WHEN c.id IS NULL THEN 'unclaimed' ELSE c.cert_no END AS certificate FROM payments p LEFT JOIN certificates c ON c.reference=p.reference ORDER BY p.paid_at DESC`).all());
      if (p === '/api/admin/certificates.csv') {
        const rows = db.prepare('SELECT cert_no,name,email,tier,amount_kobo/100 AS amount_naira,reference,public_display,issued_at,email_status FROM certificates ORDER BY id').all();
        const head = ['Certificate No', 'Name', 'Email', 'Tier', 'Amount (NGN)', 'Paystack reference', 'Name shown publicly', 'Issued at', 'Email status'];
        const csv = [head.map(csvCell).join(',')].concat(rows.map(r => [r.cert_no, r.name, r.email, r.tier, r.amount_naira, r.reference, r.public_display ? 'yes' : 'no', r.issued_at, r.email_status].map(csvCell).join(','))).join('\r\n');
        return send(res, 200, csv, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="flow-forward-certificates.csv"' });
      }
      if ((mm = p.match(/^\/api\/admin\/certificates\/(\d+)\/resend$/)) && m === 'POST') {
        const c = db.prepare('SELECT * FROM certificates WHERE id=?').get(parseInt(mm[1], 10));
        if (!c) return send(res, 404, { error: 'Not found' });
        const ok = await certs.deliver(db, c);
        return send(res, 200, { ok });
      }
      return send(res, 404, { error: 'Not found' });
    }

    // ---- pages
    if (m === 'GET' || m === 'HEAD') {
      if (p === '/') return serveStatic(res, 'index.html');
      if (/^\/c\/[A-Za-z0-9_-]{20,64}$/.test(p)) return serveStatic(res, 'certificate.html');
      if (p === '/admin') return serveStatic(res, 'admin.html');
      return serveStatic(res, p.replace(/^\/+/, ''));
    }
    send(res, 404, { error: 'Not found' });
  } catch (e) {
    console.error('[error]', p, e && e.message);
    if (!res.headersSent) send(res, 500, { error: 'Something went wrong. Please try again.' });
  }
});

if (require.main === module) {
  if (!cfg.paystackSecret) console.warn('WARNING: PAYSTACK_SECRET_KEY not set. Webhooks will be rejected and no certificates can be verified.');
  if (!cfg.adminToken) console.warn('WARNING: ADMIN_TOKEN not set. The admin area is disabled.');
  server.listen(cfg.port, () => console.log(`Nexa Flow Forward server on :${cfg.port} (mail: ${cfg.mailProvider}, db: ${cfg.dbPath})`));
}
module.exports = server;
