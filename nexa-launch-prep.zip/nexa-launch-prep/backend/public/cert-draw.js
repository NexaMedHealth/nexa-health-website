/* Draws the Nexa Flow Forward certificate onto a canvas. data: {name, tier, months, amountNaira, date, certNo} */
window.drawNexaCertificate = async function (cv, d, logo) {
  const W = 1600, H = 1130; cv.width = W; cv.height = H; const x = cv.getContext('2d');
  try { await document.fonts.load('800 40px Outfit'); await document.fonts.load('500 30px Outfit'); } catch (e) {}
  const sans = "Outfit, 'Segoe UI', system-ui, sans-serif", serif = "Georgia, 'Times New Roman', serif";
  const dateText = new Date(d.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
  let g = x.createLinearGradient(0, 0, W, H);
  g.addColorStop(0, '#1a0933'); g.addColorStop(0.5, '#4c1d95'); g.addColorStop(1, '#9d4edf');
  x.fillStyle = g; x.fillRect(0, 0, W, H);
  let r = x.createRadialGradient(W / 2, 250, 20, W / 2, 250, 700);
  r.addColorStop(0, 'rgba(255,255,255,.22)'); r.addColorStop(1, 'rgba(255,255,255,0)');
  x.fillStyle = r; x.fillRect(0, 0, W, H);
  x.strokeStyle = 'rgba(255,255,255,.6)'; x.lineWidth = 4; x.strokeRect(40, 40, W - 80, H - 80);
  x.strokeStyle = 'rgba(255,255,255,.28)'; x.lineWidth = 1.5; x.strokeRect(62, 62, W - 124, H - 124);
  x.textAlign = 'center'; x.fillStyle = '#fff';
  if (logo && logo.complete && logo.naturalWidth) x.drawImage(logo, W / 2 - 85, 92, 170, 170);
  x.font = `800 46px ${sans}`; x.letterSpacing = '10px'; x.fillText('FLOW FORWARD INITIATIVE', W / 2, 335);
  x.font = `500 26px ${sans}`; x.letterSpacing = '6px'; x.fillStyle = '#e4d7ff';
  x.fillText('CERTIFICATE OF IMPACT & SUPPORT', W / 2, 385); x.letterSpacing = '0px';
  x.strokeStyle = 'rgba(255,255,255,.4)'; x.lineWidth = 2; x.beginPath(); x.moveTo(W / 2 - 170, 418); x.lineTo(W / 2 + 170, 418); x.stroke();
  x.fillStyle = '#e4d7ff'; x.font = `italic 30px ${serif}`; x.fillText('This certificate is proudly presented to', W / 2, 490);
  x.fillStyle = '#fff'; let fs = 88; x.font = `italic ${fs}px ${serif}`;
  while (x.measureText(d.name).width > 1150 && fs > 36) { fs -= 4; x.font = `italic ${fs}px ${serif}`; }
  x.fillText(d.name, W / 2, 590);
  x.fillStyle = '#f1e9ff'; x.font = `400 31px ${sans}`;
  const text = `in grateful recognition of your generous sponsorship of ₦${Number(d.amountNaira).toLocaleString('en-NG')} (${d.tier}, ${d.months}-month pack), providing a girl with sanitary pads and reproductive health education so she can stay in school with dignity.`;
  let line = '', y = 672;
  text.split(' ').forEach(w => { const t = line ? line + ' ' + w : w; if (x.measureText(t).width > 1080) { x.fillText(line, W / 2, y); line = w; y += 48; } else line = t; });
  x.fillText(line, W / 2, y);
  x.strokeStyle = 'rgba(255,255,255,.7)'; x.lineWidth = 2;
  x.beginPath(); x.moveTo(190, 960); x.lineTo(570, 960); x.moveTo(W - 570, 960); x.lineTo(W - 190, 960); x.stroke();
  x.fillStyle = '#fff'; x.font = `italic 46px ${serif}`; x.fillText('Gift Aiyegbeni', 380, 940);
  x.font = `400 32px ${sans}`; x.fillText(dateText, W - 380, 940);
  x.fillStyle = '#e4d7ff'; x.font = `500 24px ${sans}`;
  x.fillText('Founder, Nexa Health', 380, 998); x.fillText('Date Issued', W - 380, 998);
  x.beginPath(); x.arc(W / 2, 925, 72, 0, Math.PI * 2); x.fillStyle = 'rgba(255,255,255,.12)'; x.fill();
  x.strokeStyle = 'rgba(255,255,255,.8)'; x.lineWidth = 3; x.stroke();
  x.beginPath(); x.arc(W / 2, 925, 60, 0, Math.PI * 2); x.lineWidth = 1.5; x.stroke();
  x.fillStyle = '#fff'; x.font = `800 22px ${sans}`; x.letterSpacing = '3px'; x.fillText('NEXA', W / 2, 922); x.font = `500 16px ${sans}`; x.fillText('HEALTH', W / 2, 946); x.letterSpacing = '0px';
  x.fillStyle = 'rgba(255,255,255,.65)'; x.font = `400 21px ${sans}`; x.fillText(`Certificate No. ${d.certNo}`, W / 2, 1060);
};
