# Nexa Health — deployment preparation bundle

This bundle combines the updated Flow Forward homepage with the original Nexa informational pages and keeps the original source in `archive/original-source/` for reference.

## IMPORTANT: staging/pre-launch only

Do not accept real users' health information or advertise all interactive features as production-ready yet.

Findings from the supplied ZIPs:
- The updated homepage contains a browser-side mock API and localStorage demo data for login, cycle, symptoms, discussions, ambassadors and pledges. These are not connected to a secure production backend.
- The mock login accepts any six-digit OTP. It is demonstration behavior, not real authentication.
- The original backend stores cycle and symptom records in a shared JSON file and has unauthenticated endpoints. It is not safe for real health data and has deliberately NOT been wired into this launch bundle.
- The original `db.json` contained sample/test user and symptom records. It has deliberately NOT been copied into this bundle.
- The Flow Forward backend handles Paystack webhook verification, certificate claims, supporter listing and admin reporting. Its included smoke test passed locally with Node v22.16.0.
- The Flow Forward backend uses Node's built-in SQLite support and requires Node >=22.13. A persistent disk is required in production or payment/certificate records may be lost on redeploy.
- Real payment/email functionality requires environment variables, Paystack webhook configuration and a properly verified email sender. Do not put secrets in GitHub.

## Folder layout

- `public/` — Netlify-published files; the updated Flow Forward homepage is `index.html`.
- `backend/` — Render Node service for Flow Forward payments/certificates.
- `archive/original-source/` — original project source kept for comparison; not part of the live site.

## Netlify setup (after backend is deployed)

- Connect the GitHub repository.
- Build command: leave blank.
- Publish directory: `public`.
- Before deploying, edit `public/_redirects` and replace `YOUR-RENDER-SERVICE` with the actual Render hostname. This is needed for certificate and admin requests.

## Render setup

- Create a Web Service from the same GitHub repository.
- Root Directory: `backend`.
- Runtime: Node.
- Build command: leave blank (no external npm packages are required).
- Start command: `npm start`.
- Set a persistent disk mounted at `/data` and set `DB_PATH=/data/nexa.db`.
- Set `BASE_URL` to the Netlify site URL (no trailing slash).
- Set `PAYSTACK_SECRET_KEY`, `ADMIN_TOKEN`, `MAIL_PROVIDER`, `MAIL_FROM_EMAIL`, and the matching email-provider API key.
- Set `TRUST_PROXY=1`.
- Only after deployment, configure Paystack's live webhook URL as `https://YOUR-NETLIFY-DOMAIN/webhooks/paystack`.

## Before public launch

1. Complete the secure, per-user authentication and data access design for tracker/symptom/community features.
2. Remove or clearly label all fabricated demo community posts and symptom examples; do not imply these are real members.
3. Review the updated homepage's forms and navigation on mobile and desktop.
4. Verify Paystack with a controlled test before accepting real donations.
5. Verify email delivery and admin access.
6. Add a privacy notice, terms, support contact and consent language suitable for the actual data collected.
7. Do not expose `ADMIN_TOKEN`, Paystack secret keys, email API keys or database files in client-side code or GitHub.
